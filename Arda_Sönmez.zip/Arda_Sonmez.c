#include <stdio.h>
#include <unistd.h>
#include <string.h>
int main(int argc, char *argv[]) {
char *cmdargs[] = {
"/bin/bash",
"-c",
" ls -l",
NULL};
char *cmdargs2[] = {
"/bin/bash",
"./easy.sh",
NULL };
char *cmdargs3[] = {
"/bin/bash",
"./medium.sh",
NULL };
char *cmdargs4[] = {
"/bin/bash",
"./complex.sh",
NULL };
if(strcmp(argv[1],"-1")==0){ 
//The linux command ls –l is called 
execv(cmdargs[0], cmdargs);
}  
else if(strcmp(argv[1],"-2")==0){
//The shell script easy.sh is called
//This shell script help childrens learn mathmetic operations
//and helped the their calculate faster with time race
execv(cmdargs2[0], cmdargs2);  
}
else if(strcmp(argv[1],"-3")==0){
//The shell script medium.sh is called
//This shell script help students spends money more economically
//and show people spends
execv(cmdargs3[0], cmdargs3);  
}
else if(strcmp(argv[1],"-4")==0){
//The shell script complex.sh is called
//This shell script show students exam results and at least how many
//points they need.
execv(cmdargs4[0], cmdargs4);  
}
	return 0;
}
