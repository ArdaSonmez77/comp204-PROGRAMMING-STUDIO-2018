#!/bin/bash
declare -a arithmetic=('7 x 7=?' '2 x 9=?' '7 x 8=?' '4 x 8=?' '6 x 9=?' '6 x 7=?' '5 x 9=?' '8 x 6=?' '3 x 7=?' '5 x 7=?');
declare -a answers=('49' '18' '56' '32' '54' '42' '45' '48' '21' '35');
tLen=${#arithmetic[@]}
echo "Are you ready for time challenge please write y or n "
read answer
if [[ "$answer" == "y" ]]
then 
echo "start"
else 
echo "run this code again when you are ready"
exit 1
fi
START=$(date +%s)
true=0
false=0
for((i=0; i<${tLen}; i++))
do
echo "What is ${arithmetic[i]}"
read person_Answer
re='^[0-9]+$'
while ! [[ $person_Answer =~ $re ]] 
do
   echo "$person_Answer is not a number please enter number"
   read person_Answer
   
done
person_Answers[i]="$person_Answer"
if [[ "person_Answers[i]" -eq "answers[i]" ]]
then 
echo "true"
true=$(($true + 1))
else
echo "false"
false=$(($false + 1))
fi
done
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "In $DIFF seconds you answer ${tLen} questions"
echo "you have $true true and $false false"

echo "question   your   answer"
for((j=0; j<${tLen}; j++))
do

echo "${arithmetic[j]}     ${person_Answers[j]}       ${answers[j]}"

done

