#!/bin/bash
i=0
temp=0
while [[ "$temp" -lt 100 ]] && [[ "$finish" != "y" ]]
do echo "Enter your grade"
read grade
re='^[0-9]+$'
while ! [[ $grade =~ $re ]] 
do
   echo "$grade is not a number please enter number"
   read grade
   
done
point[i]="$grade"
echo "What is the class average ?"
read sin
class_ave[i]="$sin"
echo "How many percent?"
read perc
re='^[0-9]+$'
while ! [[ $perc =~ $re ]] 
do
   echo "$perc is not a number please enter number"
   read perc
   
done
temp=$(($temp+ $perc))
if [[ "temp" -gt 100 ]]
then
echo "To percents have some mistakes restart please" 
i=0
oran=0
else
var[i]="$perc"
i=$(($i + 1))

echo "Is it finish write y or n"
read finish
fi
done
sum=0

for((t=0 ; t<i ; t++))
do 
difference[t]=$(((point[t] - class_ave[t]) * var[t]))
sum=$((difference[t] + $sum))


done

echo "What is the final exam percent??"
read lperc
re='^[0-9]+$'
while ! [[ $lperc =~ $re ]] 
do
   echo "$lperc is not a number please enter number"
   read lperc
   
done
check=$(($temp+$lperc))

if [[ "check" -gt 100 ]]
then
echo "there is something wrong please restart the code"
exit 1
fi

need=$(($sum / $lperc))
if [[ "need" -lt -100 ]]
then 
echo "Sorry you cant pass this lesson maybe next time good luck for next year :)"
elif [[ "need" -gt 0 ]]
then
echo -n "Good but if you want to pass this lesson maximum  $need point "
echo "backup the class average"
else
echo "If you want to pass this lesson  minimum  $need point front to class average"
fi
