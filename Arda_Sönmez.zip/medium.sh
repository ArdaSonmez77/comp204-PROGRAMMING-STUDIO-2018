#!/bin/bash
echo "How much your weekly money?"
read weekly
at=1
while [ "$weekly" -gt 0 ] && [ "$enter" != "y" ]
do
echo "What do you buy?"
read product
take[at]="$product"
echo "How much?"
read pay
re='^[0-9]+$'
while ! [[ $pay =~ $re ]] 
do
   echo "$pay is not a number please enter number"
   read pay
   
done
cost[at]="$pay"
weekly=$(($weekly -$pay))

at=$(($at + 1))
echo "Is it finish?"
echo "Please write y or n"
read enter
done
at=$(($at - 1))
if [ "$weekly" -lt 0 ]
then
echo "You bought $at product but your weekly finish"
exit 1
else

lost=0;
echo "   product            cost"
for((t=1 ; t<=at ; t++))
do
lost=$(($lost + cost[t]))
echo "$t-) ${take[$t]}-------------> ${cost[$t]}"
done
echo "+____________________________"
echo "  $at producut you bougth lost=$lost"
echo "Still you have $weekly dolar."
echo
fi
