# coding=utf-8
import PIL.Image
from tkColorChooser import askcolor
import PIL.ImageTk
from PIL import *
from Tkinter import *
import tkFileDialog
from tkColorChooser import askcolor
from PIL import ImageTk

choosenColor = (0, 0, 0)
drawingImage = None


def main():
    global root
    root = Tk()

    root.title("Painting Project")
    root.geometry("600x400")

    menu_bar = Menu(root)  # Create main menu bar
    file_menu = Menu(menu_bar, tearoff=0)  # Create the submenu (tearoff is if menu can pop out)	
    file_menu.add_command(label="Add Image!", command=openFile)  # Add commands to submenu
    file_menu.add_command(label="Save Image!", command=saveImage)
    file_menu.add_command(label="End!", command=root.destroy)
    file_menu.add_command(label="Clear", command=clear)
    menu_bar.add_cascade(label="File", menu=file_menu)  # Add the "File" drop down sub-menu in the main menu bar
    root.config(menu=menu_bar)

    pickColor = Button(root, text='Pick Color', command=getColor)
    pickColor.grid(row=0, column=0)

    root.mainloop()


# ***********************
def getColor():
    color = askcolor()
    color = str(color)
    start = color.index("((")
    stop = color.index("),")
    color = color[(start):stop]
    color = color[2:len(color)]
    r, g, b = color.split(",")
    global choosenColor
    choosenColor = int(r), int(g), int(b)
    print ("choosenColor is :", choosenColor)


def saveImage():
    drawingImage.save("D:\\PICTURES\\saved_Images\\great.png")

def clear():
    for i in range(xSize):
        for j in range(ySize):
            if labelValues[i][j] != 1:
                drawingImage.putpixel((i, j), (255, 255, 255))
    render = PhotoImage(drawingImage)
    img = Label(root, image=render)
    img.image = render
    img.place(x=150, y=100)
    img.bind("<Button-1>, printcords")

def makeNum(rgbValues):
    if len(rgbValues) == 4:
        r, g, b, f = rgbValues
    else:
        r, g, b = rgbValues
    average = (r + g + b) / 3
    if average == 255:
        return 1  # means white
    return 0  # means black



def openFile():
    file_path_string = tkFileDialog.askopenfilename()
    # drawingImage=Image.open(file_path_string)
    fp = open(file_path_string, "rb")
    global drawingImage
    drawingImage = PIL.Image.open(fp)
    drawingImage = drawingImage.resize((300, 300))
    global pix
    global pixelNumber
    global labelValues
    global xSize
    global ySize
    pix = drawingImage.load()
    xSize, ySize = drawingImage.size  # Get the width and hight of the image for iterating over
    for i in range(xSize):
        for j in range(ySize):
            pix[i, j] =  makeBlack_White(pix[i, j])
    pixelNumber = [[0 for x in range(ySize)] for y in range(xSize)]
    for i in range(xSize):
        for j in range(ySize):
            pixelNumber[i][j] = makeNum(pix[i, j])
    for i in range(xSize):
        for j in range(ySize):
            if i == 0 or j == 0 or i == xSize - 1 or j == ySize - 1:
                pixelNumber[i][j] = 0
    labelValues = [[0 for x in range(ySize)] for y in range(xSize)]
    for i in range(xSize):
        for j in range(ySize):
            labelValues[i][j] = 0
    labelCounter = 2  # labels start from 2
    for i in range(1, xSize - 1):
        for j in range(1, ySize - 1):
            if pixelNumber[i][j] == 1:  # current is White
                if pixelNumber[i - 1][j] == 1 and pixelNumber[i][j - 1] == 1:
                    if labelValues[i - 1][j] == labelValues[i][j - 1]:
                        labelValues[i][j] = labelValues[i][j - 1]
                    else:
                        labelValues[i][j] = labelValues[i - 1][j]
                        for t in range(0, i + 1):
                            for k in range(0, j + 1):
                                if labelValues[t][k] == labelValues[i][j - 1]:
                                    labelValues[t][k] = labelValues[i - 1][j]
                elif pixelNumber[i - 1][j] == 1 or pixelNumber[i][j - 1] == 1:
                    if pixelNumber[i - 1][j] == 1:
                        labelValues[i][j] = labelValues[i - 1][j]
                    else:
                        labelValues[i][j] = labelValues[i][j - 1]
                else:  ##current is white but neighbors are black
                    labelValues[i][j] = labelCounter
                    labelCounter += 1
            else:
                labelValues[i][j] = 1  # means blacks labels is one
    addToScreen(drawingImage)


def addToScreen(Img):
    render = ImageTk.PhotoImage(Img)
    img = Label(root, image=render)
    img.image = render
    img.place(x=150, y=50)
    img.bind("<Button-1>", printcoords)


def printcoords(event):
    # outputting x and y coords to console
    print (event.x, event.y)
    paintReagion(event.x, event.y)


def paintReagion(x, y):
    global choosenColor
    pix[x, y] = choosenColor
    for i in range(xSize):
        for j in range(ySize):
            if labelValues[i][j]==labelValues[x][y] and labelValues[i][j] != 1 and labelValues[i][j]!=0:
                drawingImage.putpixel((i, j), choosenColor)
    render = ImageTk.PhotoImage(drawingImage)
    img = Label(root, image=render)
    img.image = render
    img.place(x=150, y=50)
    img.bind("<Button-1>", printcoords)


def makeBlack_White(rgbValues):
    if len(rgbValues) == 4:
        r, g, b, f = rgbValues
    else:
        r, g, b = rgbValues
    average = (r + g + b) / 3
    if average > 200:
        return 255, 255, 255
    return 0, 0, 0


if __name__ == '__main__':
    main()